<%-- 
    layout.jsp - Layout chung với tone CAM FPT
    Phong cách: Sáng – Chuyên nghiệp – Hiện đại
--%>

<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FPT POLYTECHNIC • Lab 8</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --fpt-orange: #f36f21;
            --fpt-orange-light: #ff8b3d;
            --text-dark: #2b2b2b;
            --text-muted: #555;
            --bg-light: #fafafa;
            --card-bg: #ffffff;
            --border-light: #eaeaea;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Montserrat', sans-serif;
            background: var(--bg-light);
            color: var(--text-dark);
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* HEADER */
        header {
            background: var(--fpt-orange);
            padding: 30px 20px;
            text-align: center;
            color: white;
            box-shadow: 0 4px 10px rgba(0,0,0,0.12);
        }

        .header-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 12px;
        }

        .logo-container img {
            max-height: 70px;
        }

        header h1 {
            font-size: 2.2rem;
            font-weight: 700;
            letter-spacing: 1px;
        }

        .header-tagline {
            font-size: 0.9rem;
            opacity: 0.9;
            letter-spacing: 2px;
        }

        /* NAVBAR */
        nav {
            background: white;
            border-bottom: 1px solid var(--border-light);
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
        }

        nav .nav-container {
            max-width: 1200px;
            margin: auto;
            padding: 12px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        nav .menu {
            list-style: none;
            display: flex;
            gap: 28px;
        }

        nav .menu a {
            text-decoration: none;
            font-weight: 600;
            color: var(--text-dark);
            position: relative;
            padding-bottom: 6px;
        }

        nav .menu a::after {
            content: "";
            position: absolute;
            height: 3px;
            left: 0;
            bottom: 0;
            width: 0%;
            background: var(--fpt-orange);
            transition: 0.3s;
        }

        nav .menu a:hover::after {
            width: 100%;
        }

        nav .lang-switcher a {
            padding: 6px 16px;
            text-decoration: none;
            background: var(--fpt-orange);
            color: white;
            border-radius: 20px;
            font-size: 0.85rem;
            transition: 0.3s;
        }

        nav .lang-switcher a:hover {
            background: var(--fpt-orange-light);
        }

        /* MAIN */
        main {
            flex: 1;
            max-width: 1150px;
            margin: 40px auto;
            padding: 20px;
        }

        .content-wrapper {
            background: var(--card-bg);
            border: 1px solid var(--border-light);
            border-radius: 14px;
            padding: 40px;
            box-shadow: 0 6px 25px rgba(0,0,0,0.06);
        }

        .content-wrapper h2 {
            color: var(--fpt-orange);
            font-size: 1.9rem;
            font-weight: 700;
            text-transform: uppercase;
            margin-bottom: 22px;
            letter-spacing: 1px;
        }

        /* FOOTER */
        footer {
            background: #ffffff;
            padding: 20px 10px 40px;
            border-top: 1px solid var(--border-light);
            text-align: center;
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        .socials {
            margin-top: 10px;
            display: flex;
            justify-content: center;
            gap: 16px;
        }

        .socials a {
            color: var(--fpt-orange);
            font-size: 1.2rem;
            transition: 0.3s;
        }

        .socials a:hover {
            color: var(--fpt-orange-light);
            transform: translateY(-3px);
        }
    </style>
</head>

<body>

<header>
    <div class="header-container">
        <h1>FPT POLYTECHNIC</h1>
        <p class="header-tagline">Lab 8 · Multilingual</p>
    </div>
</header>

<nav>
    <div class="nav-container">
        <fmt:setLocale value="${sessionScope.lang != null ? sessionScope.lang : 'vi'}" scope="request" />
        <fmt:setBundle basename="global" scope="request" />
        <c:url var="home" value="/home" />

        <ul class="menu">
            <li><a href="${home}/index"><fmt:message key="menu.home" /></a></li>
            <li><a href="${home}/about"><fmt:message key="menu.about" /></a></li>
            <li><a href="${home}/contact"><fmt:message key="menu.contact" /></a></li>
        </ul>

        <div class="lang-switcher">
            <a href="?lang=vi">VI</a>
            <a href="?lang=en">EN</a>
        </div>
    </div>
</nav>

<main>
    <div class="content-wrapper">
        <jsp:include page="${view}" />
    </div>
</main>

<footer>
    <p>© 2025 · LAB8 JAVA3 · FPT Polytechnic · Designed by Nguyên</p>

    <div class="socials">
        <a href="#"><i class="fab fa-facebook"></i></a>
        <a href="#"><i class="fas fa-envelope"></i></a>
        <a href="#"><i class="fas fa-phone"></i></a>
        <a href="#"><i class="fab fa-youtube"></i></a>
    </div>
</footer>

</body>
</html>
