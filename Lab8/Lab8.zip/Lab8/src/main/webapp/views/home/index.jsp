<%-- 
    index.jsp - Trang chủ
    
    Chức năng:
    - Hiển thị nội dung trang chủ
    - Sử dụng JSTL để hiển thị tiêu đề đa ngôn ngữ
--%>

<%@ page pageEncoding="utf-8"%>
<%-- JSTL Format: Dùng cho đa ngôn ngữ --%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>

<%-- 
    Thiết lập locale từ session (giống như trong layout.jsp)
    - Nếu session.lang = "vi" → hiển thị tiếng Việt
    - Nếu session.lang = "en" → hiển thị tiếng Anh
--%>
<fmt:setLocale value="${sessionScope.lang != null ? sessionScope.lang : 'vi'}" scope="request" />

<%-- 
    Load file properties "home" để lấy text cho trang này
    - Nếu locale = "vi" → load home_vi.properties
    - Nếu locale = "en" → load home_en.properties
--%>
<fmt:setBundle basename="home" scope="request" />

<%-- 
    Hiển thị tiêu đề trang chủ đa ngôn ngữ
    - key="index.title" → Tìm trong home_*.properties
    - Nếu locale = "vi" → hiển thị "TRANG CHỦ"
    - Nếu locale = "en" → hiển thị "HOME PAGE"
--%>
<h2><fmt:message key="index.title" /></h2>

<div style="margin-top: 30px; line-height: 1.8; color: #333;">
    <p style="font-size: 1.1em; margin-bottom: 15px;">
        Chào mừng bạn đến với trang chủ của FPT Polytechnic!
    </p>
    <p style="font-size: 1.1em; margin-bottom: 15px;">
        Welcome to FPT Polytechnic homepage!
    </p>
    <p style="color: #666; margin-top: 20px;">
        Đây là trang chủ của website với giao diện hiện đại và chuyên nghiệp.
    </p>
</div>

