<%-- 
    contact.jsp - Trang liên hệ
    
    Chức năng:
    - Hiển thị nội dung trang liên hệ
    - Sử dụng JSTL để hiển thị tiêu đề đa ngôn ngữ
--%>

<%@ page pageEncoding="utf-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>

<%-- Thiết lập locale từ session --%>
<fmt:setLocale value="${sessionScope.lang != null ? sessionScope.lang : 'vi'}" scope="request" />

<%-- Load file properties "home" để lấy text --%>
<fmt:setBundle basename="home" scope="request" />

<%-- 
    Hiển thị tiêu đề trang liên hệ đa ngôn ngữ
    - key="contact.title" → Tìm trong home_*.properties
    - Nếu locale = "vi" → hiển thị "LIÊN HỆ"
    - Nếu locale = "en" → hiển thị "CONTACT US"
--%>
<h2><fmt:message key="contact.title" /></h2>

<div style="margin-top: 20px; line-height: 1.8; color:#444;">
    <p style="font-size:1.05em;">Liên hệ với chúng tôi qua thông tin sau:</p>
    <div style="background:#fff5ec; padding:18px; border-left:4px solid #f36f21; border-radius:6px; margin-top:15px;">
        <p><strong>Email:</strong> info@fpt.edu.vn</p>
        <p><strong>Phone:</strong> 1900 636 636</p>
        <p><strong>Address:</strong> Tòa nhà FPT, Khu CNC, Quận 9, TP.HCM</p>
    </div>
</div>


