<%-- 
    about.jsp - Trang giới thiệu
    
    Chức năng:
    - Hiển thị nội dung trang giới thiệu
    - Sử dụng JSTL để hiển thị tiêu đề đa ngôn ngữ
--%>

<%@ page pageEncoding="utf-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>

<%-- Thiết lập locale từ session --%>
<fmt:setLocale value="${sessionScope.lang != null ? sessionScope.lang : 'vi'}" scope="request" />

<%-- Load file properties "home" để lấy text --%>
<fmt:setBundle basename="home" scope="request" />

<%-- 
    Hiển thị tiêu đề trang giới thiệu đa ngôn ngữ
    - key="about.title" → Tìm trong home_*.properties
    - Nếu locale = "vi" → hiển thị "GIỚI THIỆU"
    - Nếu locale = "en" → hiển thị "ABOUT US"
--%>
<h2><fmt:message key="about.title" /></h2>

<div style="margin-top: 20px; line-height:1.8; color:#444;">
    <p>FPT Polytechnic là một trong những trường đào tạo CNTT hàng đầu Việt Nam.</p>
    <p>FPT Polytechnic is one of the leading IT training institutions in Vietnam.</p>
    <p style="margin-top:15px; color:#666;">
        Chúng tôi cam kết mang đến cho sinh viên chương trình đào tạo chất lượng và cơ hội nghề nghiệp tốt nhất.
    </p>
</div>


