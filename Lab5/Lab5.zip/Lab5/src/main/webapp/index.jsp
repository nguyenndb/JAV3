<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Lab 5 - FPT Polytechnic</title>
</head>
<body>
<a href="save">Bài 1</a> ||
<a href="mail">Bài 2</a> ||
<a href="login">Bài 3</a> ||
</body>
</html>