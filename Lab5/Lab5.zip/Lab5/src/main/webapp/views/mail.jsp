<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Gửi Email</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow">
                <div class="card-header bg-danger text-white">
                    <h3 class="mb-0">Gửi Email (JavaMail)</h3>
                </div>
                
                <div class="card-body">
                    <c:if test="${not empty message}">
                        <div class="alert alert-info">
                            ${message}
                        </div>
                    </c:if>

                    <form action="<c:url value='/mail'/>" method="post">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Người nhận (To):</label>
                            <input type="email" name="to" class="form-control" placeholder="nguoinhan@gmail.com" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Tiêu đề (Subject):</label>
                            <input name="subject" class="form-control" placeholder="Nhập tiêu đề..." required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Nội dung (Body):</label>
                            <textarea name="body" class="form-control" rows="5" placeholder="Nhập nội dung thư..." required></textarea>
                        </div>

                        <div class="d-flex justify-content-between">
                            <a href="index.jsp" class="btn btn-secondary">Quay về</a>
                            <button type="submit" class="btn btn-danger">Gửi ngay</button>
                        </div>
                    </form>
                </div>
                
                <div class="card-footer text-muted small">
                    Lưu ý: Quá trình gửi có thể mất vài giây. Vui lòng kiên nhẫn.
                </div>
            </div>
        </div>
    </div>

</body>
</html>