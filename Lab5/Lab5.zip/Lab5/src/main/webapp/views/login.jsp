<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Đăng nhập hệ thống</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-5">
                
                <div class="card shadow-lg">
                    <div class="card-header bg-primary text-white text-center">
                        <h3>ĐĂNG NHẬP</h3>
                    </div>
                    
                    <div class="card-body p-4">
                        
                        <c:if test="${not empty message}">
                            <div class="alert ${message.contains('thành công') ? 'alert-success' : 'alert-danger'} text-center">
                                ${message}
                            </div>
                        </c:if>

                        <form action="<c:url value='/login'/>" method="post">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Tên đăng nhập</label>
                                <input name="username" value="${username}" class="form-control" placeholder="admin">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label fw-bold">Mật khẩu</label>
                                <input type="password" name="password" value="${password}" class="form-control" placeholder="123">
                            </div>
                            
                            <div class="mb-3 form-check">
                                <input type="checkbox" name="remember" class="form-check-input" id="remember" ${checked}>
                                <label class="form-check-label" for="remember">Ghi nhớ tài khoản? (Remember me)</label>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary btn-lg">Đăng nhập</button>
                            </div>
                        </form>

                    </div>
                    <div class="card-footer text-center py-3">
                        <a href="index.jsp" class="text-decoration-none">Quay lại trang chủ</a>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

</body>
</html>