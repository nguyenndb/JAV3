<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Thông tin nhân viên</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4 mb-5">

    <div class="row">
        <div class="col-md-5">
            <h3 class="mb-3 text-primary">Nhập liệu</h3>
            
            <form action="<c:url value='/save'/>" method="post" class="card p-3 shadow-sm">
                
                <div class="mb-2">
                    <label class="form-label fw-bold">Họ và tên:</label>
                    <input name="fullname" value="${staff.fullname}" class="form-control" placeholder="Ví dụ: Nguyễn Văn A">
                </div>

                <div class="mb-2">
                    <label class="form-label fw-bold">Ngày sinh (MM/dd/yyyy):</label>
                    <input name="birthday" value="<fmt:formatDate value='${staff.birthday}' pattern='MM/dd/yyyy'/>" class="form-control" placeholder="11/25/2000">
                </div>

                <div class="mb-2">
                    <label class="form-label fw-bold">Giới tính:</label> <br>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="gender" value="true" ${staff.gender ? 'checked' : ''}> 
                        <label class="form-check-label">Nam</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="gender" value="false" ${!staff.gender && staff.gender != null ? 'checked' : ''}> 
                        <label class="form-check-label">Nữ</label>
                    </div>
                </div>

                <div class="mb-2">
                    <label class="form-label fw-bold">Sở thích:</label> <br>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" name="hobbies" value="Đọc sách"> Đọc sách
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" name="hobbies" value="Du lịch"> Du lịch
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" name="hobbies" value="Âm nhạc"> Âm nhạc
                    </div>
                </div>

                <div class="mb-2">
                    <label class="form-label fw-bold">Quốc tịch:</label>
                    <select name="country" class="form-select">
                        <option value="Việt Nam" ${staff.country == 'Việt Nam' ? 'selected' : ''}>Việt Nam</option>
                        <option value="Mỹ" ${staff.country == 'Mỹ' ? 'selected' : ''}>United States</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">Lương:</label>
                    <input name="salary" value="${staff.salary}" class="form-control" placeholder="Nhập số lương">
                </div>

                <div class="d-grid gap-2 d-md-block">
                    <button type="submit" class="btn btn-success">
                        <i class="bi bi-eye"></i> Xem thông tin
                    </button>
                    
                    <button type="reset" class="btn btn-outline-secondary">Làm mới</button>
                </div>
            </form>
            
            <div class="mt-3">
                <a href="index.jsp" class="text-decoration-none">&laquo; Quay lại trang chủ</a>
            </div>
        </div>

        <div class="col-md-7">
            <c:if test="${not empty staff.fullname}">
                <h3 class="mb-3 text-success">Thông tin chi tiết</h3>
                
                <div class="card shadow border-success">
                    <div class="card-header bg-success text-white">
                        Kết quả từ BeanUtils
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <tr>
                                <th style="width: 30%">Họ và tên:</th>
                                <td>${staff.fullname}</td>
                            </tr>
                            <tr>
                                <th>Ngày sinh:</th>
                                <td><fmt:formatDate value="${staff.birthday}" pattern="dd-MM-yyyy"/></td>
                            </tr>
                            <tr>
                                <th>Giới tính:</th>
                                <td>
                                    <span class="badge ${staff.gender ? 'bg-primary' : 'bg-danger'}">
                                        ${staff.gender ? 'Nam' : 'Nữ'}
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <th>Quốc tịch:</th>
                                <td>${staff.country}</td>
                            </tr>
                            <tr>
                                <th>Lương:</th>
                                <td class="fw-bold text-danger">
                                    <fmt:formatNumber value="${staff.salary}" type="currency" currencySymbol="VNĐ"/>
                                </td>
                            </tr>
                            <tr>
                                <th>Sở thích:</th>
                                <td>
                                    <c:forEach var="hobby" items="${staff.hobbies}">
                                        <span class="badge bg-secondary me-1">${hobby}</span>
                                    </c:forEach>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </c:if>
            
            <c:if test="${empty staff.fullname}">
                <div class="alert alert-info mt-5">
                    Hãy nhập thông tin vào form bên trái và bấm nút <strong>"Xem thông tin"</strong> để hiển thị kết quả tại đây.
                </div>
            </c:if>
        </div>
    </div>

</body>
</html>