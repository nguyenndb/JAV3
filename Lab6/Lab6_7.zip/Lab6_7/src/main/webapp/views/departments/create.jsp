<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm Mới Phòng Ban - HRM System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            padding-bottom: 100px;
        }
    </style>
</head>
<body>
    
    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-header text-white" style="background-color: #28a745;">
                        <h4 class="mb-0"><i class="fas fa-plus-circle me-2"></i> Thêm Mới Phòng Ban</h4>
                    </div>
                    <div class="card-body">
                        <form action="${pageContext.request.contextPath}/departments" method="post">
                            <input type="hidden" name="action" value="create">
                            
                            <div class="mb-3">
                                <label for="id" class="form-label">Mã Phòng <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="id" name="id" 
                                       maxlength="3" required placeholder="VD: IT, HR, MK">
                                <div class="form-text">Mã phòng tối đa 3 ký tự</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="name" class="form-label">Tên Phòng <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="name" name="name" 
                                       maxlength="50" required placeholder="Nhập tên phòng ban">
                            </div>
                            
                            <div class="mb-3">
                                <label for="description" class="form-label">Mô Tả</label>
                                <textarea class="form-control" id="description" name="description" 
                                          rows="3" maxlength="255" placeholder="Nhập mô tả phòng ban"></textarea>
                            </div>
                            
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <a href="${pageContext.request.contextPath}/departments?action=list" 
                                   class="btn btn-secondary me-md-2">
                                    <i class="fas fa-times-circle me-1"></i> Hủy
                                </a>
                                <button type="submit" class="btn btn-success">
                                    <i class="fas fa-check-circle me-1"></i> Lưu
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <jsp:include page="/views/layout/footer.jsp"/>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

