<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh Sách Phòng Ban - HRM System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            padding-bottom: 100px;
        }
    </style>
</head>
<body>
    
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="text-success"><i class="fas fa-building me-2"></i> Danh Sách Phòng Ban</h2>
            <a href="${pageContext.request.contextPath}/departments?action=create" class="btn btn-success">
                <i class="fas fa-plus-circle me-1"></i> Thêm Mới
            </a>
        </div>
        
        <div class="card shadow-sm">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-success">
                            <tr>
                                <th>Mã Phòng</th>
                                <th>Tên Phòng</th>
                                <th>Mô Tả</th>
                                <th class="text-center">Thao Tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="dept" items="${departments}">
                                <tr>
                                    <td><strong>${dept.id}</strong></td>
                                    <td>${dept.name}</td>
                                    <td>${dept.description}</td>
                                    <td class="text-center">
                                        <a href="${pageContext.request.contextPath}/departments?action=edit&id=${dept.id}" 
                                           class="btn btn-sm me-1" style="background-color: #20c997; color: white;">
                                            <i class="fas fa-edit me-1"></i> Sửa
                                        </a>
                                        <a href="${pageContext.request.contextPath}/departments?action=delete&id=${dept.id}" 
                                           class="btn btn-sm btn-danger"
                                           onclick="return confirm('Bạn có chắc chắn muốn xóa phòng ban này?')">
                                            <i class="fas fa-trash me-1"></i> Xóa
                                        </a>
                                    </td>
                                </tr>
                            </c:forEach>
                            <c:if test="${empty departments}">
                                <tr>
                                    <td colspan="4" class="text-center text-muted">
                                        <i class="bi bi-inbox"></i> Chưa có dữ liệu
                                    </td>
                                </tr>
                            </c:if>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <div class="mt-3">
            <a href="${pageContext.request.contextPath}/" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i> Về Trang Chủ
            </a>
        </div>
    </div>
    
    <jsp:include page="/views/layout/footer.jsp"/>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

