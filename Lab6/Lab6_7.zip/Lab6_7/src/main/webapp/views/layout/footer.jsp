<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<footer class="bg-dark text-white py-3 mt-4 fixed-bottom w-100">
    <div class="container d-flex flex-column flex-md-row justify-content-between align-items-center">
        <p class="mb-2 mb-md-0">
            &copy; 2025 LAB6 - LAB7 JAV3 - FPT Polytechnic | I'm Khánh
        </p>
        <div class="d-flex gap-4">
            <a href="#" class="text-white fs-6" title="Facebook">
                <i class="fab fa-facebook"></i>
            </a>
            <a href="#" class="text-white fs-6" title="Email">
                <i class="fas fa-envelope"></i>
            </a>
            <a href="#" class="text-white fs-6" title="Phone">
                <i class="fas fa-phone"></i>
            </a>
            <a href="#" class="text-white fs-6" title="YouTube">
                <i class="fab fa-youtube"></i>
            </a>
        </div>
    </div>
</footer>
