<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm Mới Nhân Viên - HRM System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            padding-bottom: 100px;
        }
    </style>
</head>
<body>
    
    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card shadow-sm">
                    <div class="card-header text-white" style="background-color: #28a745;">
                        <h4 class="mb-0"><i class="fas fa-plus-circle me-2"></i> Thêm Mới Nhân Viên</h4>
                    </div>
                    <div class="card-body">
                        <form action="${pageContext.request.contextPath}/employees" method="post">
                            <input type="hidden" name="action" value="create">
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="id" class="form-label">Mã Nhân Viên <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="id" name="id" 
                                           maxlength="20" required placeholder="VD: NV001">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="password" class="form-label">Mật Khẩu <span class="text-danger">*</span></label>
                                    <input type="password" class="form-control" id="password" name="password" 
                                           maxlength="50" required>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="fullname" class="form-label">Họ và Tên <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="fullname" name="fullname" 
                                           maxlength="50" required>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="photo" class="form-label">Hình Ảnh <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="photo" name="photo" 
                                           maxlength="50" required placeholder="VD: avatar.jpg">
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Giới Tính <span class="text-danger">*</span></label>
                                    <div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="gender" 
                                                   id="genderMale" value="true" checked>
                                            <label class="form-check-label" for="genderMale">Nam</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="gender" 
                                                   id="genderFemale" value="false">
                                            <label class="form-check-label" for="genderFemale">Nữ</label>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-4 mb-3">
                                    <label for="birthday" class="form-label">Ngày Sinh <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control" id="birthday" name="birthday" required>
                                </div>
                                
                                <div class="col-md-4 mb-3">
                                    <label for="salary" class="form-label">Lương <span class="text-danger">*</span></label>
                                    <input type="number" class="form-control" id="salary" name="salary" 
                                           step="0.01" min="0" required>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="departmentId" class="form-label">Phòng Ban <span class="text-danger">*</span></label>
                                <select class="form-select" id="departmentId" name="departmentId" required>
                                    <option value="">-- Chọn Phòng Ban --</option>
                                    <c:forEach var="dept" items="${departments}">
                                        <option value="${dept.id}">${dept.name}</option>
                                    </c:forEach>
                                </select>
                            </div>
                            
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <a href="${pageContext.request.contextPath}/employees?action=list" 
                                   class="btn btn-secondary me-md-2">
                                    <i class="fas fa-times-circle me-1"></i> Hủy
                                </a>
                                <button type="submit" class="btn btn-success">
                                    <i class="fas fa-check-circle me-1"></i> Lưu
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <jsp:include page="/views/layout/footer.jsp"/>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

