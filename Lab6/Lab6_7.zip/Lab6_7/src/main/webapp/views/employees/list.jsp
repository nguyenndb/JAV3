<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh Sách Nhân Viên - HRM System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            padding-bottom: 100px;
        }
    </style>
</head>
<body>
    
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="text-success"><i class="fas fa-users me-2"></i> Danh Sách Nhân Viên</h2>
            <a href="${pageContext.request.contextPath}/employees?action=create" class="btn btn-success">
                <i class="fas fa-plus-circle me-1"></i> Thêm Mới
            </a>
        </div>
        
        <div class="card shadow-sm">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-success">
                            <tr>
                                <th>Mã NV</th>
                                <th>Hình Ảnh</th>
                                <th>Họ Tên</th>
                                <th>Giới Tính</th>
                                <th>Ngày Sinh</th>
                                <th>Lương</th>
                                <th>Phòng Ban</th>
                                <th class="text-center">Thao Tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="emp" items="${employees}">
                                <tr>                  
                                    <td><strong>${emp.id}</strong></td>
                                    <td>
									    <img src="${pageContext.request.contextPath}/img/${emp.photo}" 
									         alt="${emp.fullname}" 
									         style="width:45px; height:45px; object-fit:cover; border-radius:50%; border:1px solid #ccc;"
									         onerror="this.src='${pageContext.request.contextPath}/img/default-avatar.png'; this.onerror=null;">
									</td>
                                    <td>${emp.fullname}</td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${emp.gender}">
                                                <span class="badge bg-success">Nam</span>
                                            </c:when>
                                            <c:otherwise>
                                                <span class="badge bg-danger">Nữ</span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td>${emp.birthday}</td>
                                    <td>
                                        <fmt:formatNumber value="${emp.salary}" type="currency" currencyCode="VND" 
                                                          pattern="#,##0.00" /> VNĐ
                                    </td>
                                    <td>
                                        <c:forEach var="dept" items="${departments}">
                                            <c:if test="${dept.id == emp.departmentId}">
                                                ${dept.name}
                                            </c:if>
                                        </c:forEach>
                                    </td>
                                    <td class="text-center">
                                        <a href="${pageContext.request.contextPath}/employees?action=view&id=${emp.id}" 
                                           class="btn btn-sm btn-info text-white me-1">
                                            <i class="fas fa-eye me-1"></i> Xem
                                        </a>
                                        <a href="${pageContext.request.contextPath}/employees?action=edit&id=${emp.id}" 
                                           class="btn btn-sm me-1" style="background-color: #20c997; color: white;">
                                            <i class="fas fa-edit me-1"></i> Sửa
                                        </a>
                                        <a href="${pageContext.request.contextPath}/employees?action=delete&id=${emp.id}" 
                                           class="btn btn-sm btn-danger"
                                           onclick="return confirm('Bạn có chắc chắn muốn xóa nhân viên này?')">
                                            <i class="fas fa-trash me-1"></i> Xóa
                                        </a>
                                    </td>
                                </tr>
                            </c:forEach>
                            <c:if test="${empty employees}">
                                <tr>
                                    <td colspan="7" class="text-center text-muted">
                                        <i class="fas fa-inbox fa-2x mb-2"></i><br>
                                        Chưa có dữ liệu
                                    </td>
                                </tr>
                            </c:if>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <div class="mt-3">
            <a href="${pageContext.request.contextPath}/" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i> Về Trang Chủ
            </a>
        </div>
    </div>
    
    <jsp:include page="/views/layout/footer.jsp"/>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

