<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thông Tin Nhân Viên - HRM System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            padding-bottom: 100px;
        }
        .profile-header {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            padding: 40px 0;
            margin-bottom: 30px;
        }
        .profile-avatar {
            width: 150px;
            height: 150px;
            border: 5px solid white;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .info-card {
            border-left: 4px solid #28a745;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .info-card:hover {
            transform: translateX(5px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    
    <div class="profile-header">
        <div class="container text-center">
            <img src="${pageContext.request.contextPath}/img/${employee.photo}" 
                 alt="${employee.fullname}" 
                 class="rounded-circle profile-avatar mb-3"
                 style="object-fit: cover;"
                 onerror="this.src='${pageContext.request.contextPath}/img/default-avatar.png'; this.onerror=null;">
            <h2 class="mb-2">${employee.fullname}</h2>
            <p class="mb-0 opacity-75">
                <i class="fas fa-id-badge me-2"></i>Mã Nhân Viên: ${employee.id}
            </p>
        </div>
    </div>
    
    <div class="container">
        <div class="row g-4">
            <!-- Thông Tin Cá Nhân -->
            <div class="col-md-6">
                <div class="card shadow-sm info-card h-100">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">
                            <i class="fas fa-user me-2"></i>Thông Tin Cá Nhân
                        </h5>
                    </div>
                    <div class="card-body">
                        <table class="table table-borderless">
                            <tr>
                                <td class="fw-bold" style="width: 40%;">
                                    <i class="fas fa-id-card text-success me-2"></i>Mã Nhân Viên:
                                </td>
                                <td>${employee.id}</td>
                            </tr>
                            <tr>
                                <td class="fw-bold">
                                    <i class="fas fa-user text-success me-2"></i>Họ và Tên:
                                </td>
                                <td>${employee.fullname}</td>
                            </tr>
                            <tr>
                                <td class="fw-bold">
                                    <i class="fas fa-venus-mars text-success me-2"></i>Giới Tính:
                                </td>
                                <td>
                                    <c:choose>
                                        <c:when test="${employee.gender}">
                                            <span class="badge bg-success">Nam</span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="badge bg-danger">Nữ</span>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                            </tr>
                            <tr>
                                <td class="fw-bold">
                                    <i class="fas fa-birthday-cake text-success me-2"></i>Ngày Sinh:
                                </td>
                                <td>${employee.birthday}</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Thông Tin Công Việc -->
            <div class="col-md-6">
                <div class="card shadow-sm info-card h-100">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">
                            <i class="fas fa-briefcase me-2"></i>Thông Tin Công Việc
                        </h5>
                    </div>
                    <div class="card-body">
                        <table class="table table-borderless">
                            <tr>
                                <td class="fw-bold" style="width: 40%;">
                                    <i class="fas fa-building text-success me-2"></i>Phòng Ban:
                                </td>
                                <td>
                                    <c:forEach var="dept" items="${departments}">
                                        <c:if test="${dept.id == employee.departmentId}">
                                            <span class="badge bg-info text-dark">${dept.name}</span>
                                        </c:if>
                                    </c:forEach>
                                </td>
                            </tr>
                            <tr>
                                <td class="fw-bold">
                                    <i class="fas fa-money-bill-wave text-success me-2"></i>Lương:
                                </td>
                                <td>
                                    <strong class="text-success">
                                        <fmt:formatNumber value="${employee.salary}" type="currency" currencyCode="VND" 
                                                          pattern="#,##0.00" /> VNĐ
                                    </strong>
                                </td>
                            </tr>
                            <tr>
                                <td class="fw-bold">
                                    <i class="fas fa-key text-success me-2"></i>Mật Khẩu:
                                </td>
                                <td>
                                    <span class="text-muted">••••••••</span>
                                    <small class="text-muted ms-2">(Đã mã hóa)</small>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Nút Thao Tác -->
        <div class="mt-4 d-flex justify-content-center gap-2">
            <a href="${pageContext.request.contextPath}/employees?action=list" 
               class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i> Quay Lại Danh Sách
            </a>
            <a href="${pageContext.request.contextPath}/employees?action=edit&id=${employee.id}" 
               class="btn btn-success">
                <i class="fas fa-edit me-1"></i> Chỉnh Sửa
            </a>
        </div>
    </div>
    
    <jsp:include page="/views/layout/footer.jsp"/>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

