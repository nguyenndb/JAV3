<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HRM System - Trang Chủ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            padding-bottom: 100px;
        }
        .hero-section {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            padding: 60px 0;
            margin-bottom: 40px;
        }
        .card {
            transition: transform 0.3s, box-shadow 0.3s;
            border: none;
            border-radius: 15px;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }
        .card-icon {
            font-size: 4rem;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    
    <div class="hero-section">
        <div class="container text-center">
            <h1 class="display-4 fw-bold mb-3">
                <i class="fas fa-users-cog me-3"></i>Hệ Thống Quản Lý Nhân Sự
            </h1>
        </div>
    </div>
    
    <div class="container">
        <div class="row g-4">
            <div class="col-md-6">
                <div class="card shadow-sm h-100 text-center p-4">
                    <div class="card-body">
                        <div class="card-icon text-success">
                            <i class="fas fa-building"></i>
                        </div>
                        <h3 class="card-title mb-3">Quản Lý Phòng Ban</h3>
                        <p class="card-text text-muted mb-4">
                            Quản lý thông tin các phòng ban trong công ty với đầy đủ chức năng CRUD
                        </p>
                        <div class="d-flex gap-2 justify-content-center flex-wrap">
                            <a href="${pageContext.request.contextPath}/departments?action=list" 
                               class="btn btn-success">
                                <i class="fas fa-arrow-right me-1"></i> Xem danh sách
                            </a>
                            <a href="${pageContext.request.contextPath}/departments" 
                               class="btn" style="background-color: #20c997; color: white;">
                                <i class="fas fa-arrow-right me-1"></i> Quản lý
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card shadow-sm h-100 text-center p-4">
                    <div class="card-body">
                        <div class="card-icon text-success">
                            <i class="fas fa-users"></i>
                        </div>
                        <h3 class="card-title mb-3">Quản Lý Nhân Viên</h3>
                        <p class="card-text text-muted mb-4">
                            Quản lý thông tin nhân viên trong công ty với đầy đủ thông tin chi tiết
                        </p>
                        <a href="${pageContext.request.contextPath}/employees?action=list" 
                           class="btn btn-success">
                            <i class="fas fa-arrow-right me-1"></i> Xem Danh Sách
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <jsp:include page="/views/layout/footer.jsp"/>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
