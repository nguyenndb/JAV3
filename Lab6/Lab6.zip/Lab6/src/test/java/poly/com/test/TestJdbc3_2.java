package poly.com.test;

import poly.com.utils.Jdbc;

import java.sql.ResultSet;

public class TestJdbc3_2 {
    public static void main(String[] args) {

        // --- 1. SELECT nhân viên (có dùng PreparedStatement với values) ---
        try {
            String sqlSelect = "SELECT e.Id, e.Fullname, e.Salary, d.Name as DeptName " +
                               "FROM Employees e JOIN Departments d ON e.DepartmentId = d.id " +
                               "WHERE e.Salary > ?";
            Object[] valuesSelect = {50000}; // Ví dụ lấy nhân viên có lương > 50000
            ResultSet rs = Jdbc.executeQuery(sqlSelect, valuesSelect);

            System.out.println("Danh sách nhân viên có lương > 50000:");
            while (rs.next()) {
                String id = rs.getString("Id");
                String name = rs.getString("Fullname");
                double salary = rs.getDouble("Salary");
                String dept = rs.getString("DeptName");
                System.out.println(id + " - " + name + " - " + salary + " - " + dept);
            }
            rs.getStatement().getConnection().close(); // đóng connection sau khi dùng
        } catch (Exception e) {
            e.printStackTrace();
        }

        // --- 2. INSERT nhân viên mới ---
        try {
            String sqlInsert = "INSERT INTO Employees(Id, Password, Fullname, Photo, Gender, Birthday, Salary, DepartmentId) " +
                               "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            Object[] valuesInsert = {"E005", "pass567", "David Green", "david.jpg", 1, "1993-12-01", 47000, "002"};
            int rowsInserted = Jdbc.executeUpdate(sqlInsert, valuesInsert);
            System.out.println("Đã thêm " + rowsInserted + " nhân viên.");
        } catch (Exception e) {
            System.out.println("Lỗi INSERT (có thể nhân viên đã tồn tại): " + e.getMessage());
        }

        // --- 3. UPDATE lương nhân viên ---
        try {
            String sqlUpdate = "UPDATE Employees SET Salary = ? WHERE Id = ?";
            Object[] valuesUpdate = {70000, "E001"};
            int rowsUpdated = Jdbc.executeUpdate(sqlUpdate, valuesUpdate);
            System.out.println("Đã cập nhật " + rowsUpdated + " nhân viên.");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // --- 4. DELETE nhân viên ---
        try {
            String sqlDelete = "DELETE FROM Employees WHERE Id = ?";
            Object[] valuesDelete = {"E004"};
            int rowsDeleted = Jdbc.executeUpdate(sqlDelete, valuesDelete);
            System.out.println("Đã xóa " + rowsDeleted + " nhân viên.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
