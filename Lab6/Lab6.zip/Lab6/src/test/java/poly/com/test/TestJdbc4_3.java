package poly.com.test;

import poly.com.utils.Jdbc;

import java.sql.ResultSet;

public class TestJdbc4_3 {
    public static void main(String[] args) {
        // --- 1. Thử gọi spSelectAll ---
        System.out.println("=== Danh sách Departments ===");
        try (ResultSet rs = Jdbc.executeQuery("{CALL spSelectAll}")) {
            while (rs.next()) {
                String id = rs.getString("id");
                String name = rs.getString("Name");
                String desc = rs.getString("Description");
                System.out.println(id + " - " + name + " - " + desc);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // --- 2. Thêm mới Department ---
        System.out.println("\n=== Thêm Department D04 ===");
        try {
            int rows = Jdbc.executeUpdate("{CALL spInsert(?, ?, ?)}", "004", "Marketing", "Marketing Department");
            System.out.println("Đã thêm " + rows + " record.");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // --- 3. Cập nhật Department D04 ---
        System.out.println("\n=== Cập nhật Department D04 ===");
        try {
            int rows = Jdbc.executeUpdate("{CALL spUpdate(?, ?, ?)}", "004", "Marketing Updated", "Marketing Dept Updated");
            System.out.println("Đã cập nhật " + rows + " record.");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // --- 4. Truy vấn theo Id D04 ---
        System.out.println("\n=== Truy vấn Department D04 ===");
        try (ResultSet rs = Jdbc.executeQuery("{CALL spSelectById(?)}", "004")) {
            while (rs.next()) {
                String id = rs.getString("id");
                String name = rs.getString("Name");
                String desc = rs.getString("Description");
                System.out.println(id + " - " + name + " - " + desc);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // --- 5. Xóa Department D04 ---
        System.out.println("\n=== Xóa Department D04 ===");
        try {
            int rows = Jdbc.executeUpdate("{CALL spDeleteById(?)}", "004");
            System.out.println("Đã xóa " + rows + " record.");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // --- 6. Danh sách cuối cùng ---
        System.out.println("\n=== Danh sách Departments cuối cùng ===");
        try (ResultSet rs = Jdbc.executeQuery("{CALL spSelectAll}")) {
            while (rs.next()) {
                String id = rs.getString("id");
                String name = rs.getString("Name");
                String desc = rs.getString("Description");
                System.out.println(id + " - " + name + " - " + desc);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
