package poly.com.test;

import poly.com.utils.Jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class TestJdbc2_3 {
    public static void main(String[] args) {
        // --- 1. Thử SELECT ---
        try {
            String sqlSelect = "SELECT e.Id, e.Fullname, e.Salary, d.Name as DeptName " +
                    "FROM Employees e JOIN Departments d ON e.DepartmentId = d.id";

            try (Connection conn = Jdbc.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sqlSelect)) {

                System.out.println("Danh sách nhân viên:");
                while (rs.next()) {
                    String id = rs.getString("Id");
                    String name = rs.getString("Fullname");
                    double salary = rs.getDouble("Salary");
                    String dept = rs.getString("DeptName");
                    System.out.println(id + " - " + name + " - " + salary + " - " + dept);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        // --- 2. Thử INSERT hoặc UPDATE nếu đã tồn tại ---
        try {
            String id = "E005";

            // Kiểm tra xem nhân viên đã tồn tại chưa
            String sqlCheck = "SELECT COUNT(*) AS count FROM Employees WHERE Id='" + id + "'";
            try (Connection conn = Jdbc.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sqlCheck)) {

                int count = 0;
                if (rs.next()) {
                    count = rs.getInt("count");
                }

                if (count > 0) {
                    // Nếu đã tồn tại -> UPDATE
                    String sqlUpdate = "UPDATE Employees " +
                            "SET Password='pass567', Fullname='David Green', Photo='david.jpg', " +
                            "Gender=1, Birthday='1993-12-01', Salary=47000, DepartmentId='002' " +
                            "WHERE Id='" + id + "'";
                    int rowsUpdated = Jdbc.executeUpdate(sqlUpdate);
                    System.out.println("Đã cập nhật " + rowsUpdated + " nhân viên.");
                } else {
                    // Nếu chưa tồn tại -> INSERT
                    String sqlInsert = "INSERT INTO Employees(Id, Password, Fullname, Photo, Gender, Birthday, Salary, DepartmentId) " +
                            "VALUES('E005', 'pass567', 'David Green', 'david.jpg', 1, '1993-12-01', 47000, '002')";
                    int rowsInserted = Jdbc.executeUpdate(sqlInsert);
                    System.out.println("Đã thêm " + rowsInserted + " nhân viên.");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        // --- 3. Thử UPDATE khác ---
        try {
            String sqlUpdate = "UPDATE Employees SET Salary = 70000 WHERE Id='E001'";
            int rowsUpdated = Jdbc.executeUpdate(sqlUpdate);
            System.out.println("Đã cập nhật " + rowsUpdated + " nhân viên.");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // --- 4. Thử DELETE ---
        try {
            String sqlDelete = "DELETE FROM Employees WHERE Id='E004'";
            int rowsDeleted = Jdbc.executeUpdate(sqlDelete);
            System.out.println("Đã xóa " + rowsDeleted + " nhân viên.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
