package poly.com.utils;

import java.sql.*;

public class Jdbc {
    private static final String SERVER = "localhost";
    private static final String PORT = "1433";
    private static final String DATABASE = "lab6_java3_csdl";
    private static final String USERNAME = "sa";
    private static final String PASSWORD = "123456";

    private static final String URL = "jdbc:sqlserver://" + SERVER + ":" + PORT +
            ";databaseName=" + DATABASE +
            ";encrypt=false;trustServerCertificate=true";

    static {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Không thể load SQL Server JDBC Driver: " + e.getMessage());
        }
    }

    /** Mở kết nối */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }

    /** Đóng kết nối */
    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /** Thao tác dữ liệu (INSERT, UPDATE, DELETE) - Statement */
    public static int executeUpdate(String sql) throws SQLException {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            return stmt.executeUpdate(sql);
        }
    }

    /** Thao tác dữ liệu (INSERT, UPDATE, DELETE) - PreparedStatement */
    public static int executeUpdate(String sql, Object... values) throws SQLException {
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            for (int i = 0; i < values.length; i++) {
                stmt.setObject(i + 1, values[i]);
            }
            return stmt.executeUpdate();
        }
    }

    /** Truy vấn dữ liệu (SELECT) - Statement */
    public static ResultSet executeQuery(String sql) throws SQLException {
        Connection conn = getConnection();
        Statement stmt = conn.createStatement();
        return stmt.executeQuery(sql);
        // Caller phải đóng ResultSet + Statement + Connection sau khi dùng xong
    }

    /** Truy vấn dữ liệu (SELECT) - PreparedStatement */
    public static ResultSet executeQuery(String sql, Object... values) throws SQLException {
        Connection conn = getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
        for (int i = 0; i < values.length; i++) {
            stmt.setObject(i + 1, values[i]);
        }
        return stmt.executeQuery();
        // Caller phải đóng ResultSet + Statement + Connection sau khi dùng xong
    }
}
