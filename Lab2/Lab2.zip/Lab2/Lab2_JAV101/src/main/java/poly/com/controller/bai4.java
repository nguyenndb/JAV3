package poly.com.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/bai4")
public class bai4 extends HttpServlet {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	User bean = new User();
    bean.setFullname("Nguyễn Đình Bảo Nguyên");
    bean.setGender(true);
    bean.setCountry("VN");
    req.setAttribute("user", bean);

    // Chuyển tới trang JSP để hiển thị thông tin
    req.getRequestDispatcher("/bai4.jsp").forward(req, resp);
	
}	
}
