<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<b>YOUR INFORMATION</b>
<ul>
<li> FULLNAME: ${user.fullname} </li>
<li> Phai: ${user.gender} </li>
<li> Quốc Tịch: ${user.country} </li>
</ul>
</body>
</html>