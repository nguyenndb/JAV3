<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<h2>Thông tin người dùng</h2>
    <p>Họ tên: ${user.fullname}</p>
    <p>Giới tính: ${user.gender ? "Nam" : "Nữ"}</p>
    <p>Quốc gia: ${user.country}</p>
</body>
</html>