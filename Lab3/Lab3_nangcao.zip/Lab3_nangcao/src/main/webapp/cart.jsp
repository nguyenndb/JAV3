<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>

<html>
<head>
<title>Giỏ hàng</title>
<link rel="stylesheet" type="text/css" href="style-cart.css">
</head>
<body>

	<jsp:include page="index.jsp"></jsp:include>

	<h2 class="cart-title">Giỏ hàng của bạn</h2>

	<c:if test="${empty sessionScope.cart}">
		<p class="content" align="center">Giỏ hàng hiện đang trống.</p>
	</c:if>

	<c:if test="${not empty sessionScope.cart}">
		<table class="cart-table" border="1" cellpadding="8">
			<thead>
				<tr>
					<th>STT</th>
					<th>Tên</th>
					<th>Hình</th>
					<th>Giá</th>
					<th>Giảm</th>
					<th>Số lượng</th>
					<th>Thành tiền</th>
					<th>Hành động</th>
				</tr>
			</thead>
			<tbody>
				<c:set var="total" value="0" />
				<c:forEach var="ci" items="${sessionScope.cart}" varStatus="vs">
					<tr>
						<td>${vs.count}</td>
						<td>${ci.item.name}</td>
						<td><img
							src="${pageContext.request.contextPath}/img/${ci.item.image}"
							alt="${ci.item.name}" width="80" /></td>
						<td><fmt:formatNumber value="${ci.item.price}"
								type="currency" currencySymbol="VNĐ" /></td>
						<td><fmt:formatNumber value="${ci.item.discount * 100}"
								type="number" />%</td>
						<td>${ci.quantity}</td>
						<td><fmt:formatNumber
								value="${ci.item.price * (1 - ci.item.discount) * ci.quantity}"
								type="currency" currencySymbol="VNĐ" /> <c:set var="total"
								value="${total + ci.item.price * (1 - ci.item.discount) * ci.quantity}" />
						</td>
						<td>
							<form action="updatecart" method="post"
								style="display: inline-block">
								<input type="hidden" name="name" value="${ci.item.name}">
								<button type="submit" name="action" value="increase">+</button>
								<button type="submit" name="action" value="decrease">-</button>
								<button type="submit" name="action" value="remove">Xóa</button>
							</form>
						</td>
					</tr>
				</c:forEach>
			</tbody>
		</table>

		<div class="cart-total">
			<h3>Tổng tiền</h3>
			<p>
				<fmt:formatNumber value="${total}" type="currency"
					currencySymbol="VNĐ" />
			</p>
		</div>
	</c:if>

</body>
</html>