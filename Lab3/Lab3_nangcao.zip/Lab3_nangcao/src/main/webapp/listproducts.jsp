<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn"%>

<html>
<head>
<meta charset="UTF-8">
<title>Danh sách sản phẩm</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<jsp:include page="index.jsp"></jsp:include>
	<c:if test="${not empty sessionScope.message}">
    <div class="notification">
        ${sessionScope.message}
    </div>
    <c:remove var="message" scope="session" />
</c:if>
	
	<center>
		<h2>Danh sách sản phẩm</h2>
		<br>
		<table>
			<thead>
				<tr>
					<th>Tên sản phẩm</th>
					<th>Hình ảnh</th>
					<th>Giá</th>
					<th>Khuyến mãi</th>
					<th>Chi tiết</th>
					<th>Thêm giỏ hàng</th>
				</tr>
			</thead>
			<tbody>
				<c:forEach var="item" items="${items}">
					<tr>
						<td>${item.name}</td>
						<td><img onClick="hamchitiet('${item.name}')"
							src="${pageContext.request.contextPath}/img/${item.image}"
							alt="${item.name}" width="100" /></td>
						<td><fmt:formatNumber value="${item.price}" type="currency"
								currencySymbol="VNĐ" /></td>
						<td><fmt:formatNumber value="${item.discount * 100}"
								type="number" />%</td>
						<td><a href="viewitem?id=${item.name}">chi tiết</a></td>
						<td>
							<form action="${pageContext.request.contextPath}/addtocart"
								method="post">
								<input type="hidden" name="id" value="${item.name}">
								<button type="submit">Thêm</button>
							</form>
						</td>
					</tr>
				</c:forEach>
			</tbody>
		</table>

		<hr />
	</center>

	<script>
		function hamchitiet(itemId) {
			window.location.href = "viewitem?id=" + itemId;
		}
	</script>
</body>
</html>