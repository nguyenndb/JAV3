<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Lab3</title>
</head>
<body>
<a href="bai5">NÂNG CAO</a> ||
<a href="cart.jsp">GIỎ HÀNG</a> ||
</body>
</html>