<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn"%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>
        <c:choose>
            <c:when test="${not empty selectedItem}">${selectedItem.name} - Chi tiết sản phẩm</c:when>
            <c:otherwise>Chi Tiết Sản Phẩm</c:otherwise>
        </c:choose>
    </title>
    <link rel="stylesheet" type="text/css" href="style-detail.css">
</head>
<body>
    <jsp:include page="index.jsp"></jsp:include>

    <div class="container">
        <c:if test="${not empty selectedItem}">
            <div class="card">
                <img class="card-img" src="/Lab3_nangcao/img/${selectedItem.image}" alt="${selectedItem.name}">
                <div class="card-content">
                    <h2 class="card-title">${selectedItem.name}</h2>

                    <div class="card-discount">
                        Giảm: <fmt:formatNumber value="${selectedItem.discount * 100}" type="number"/>%
                    </div>

                    <div class="card-price">
                        <strike><fmt:formatNumber value="${selectedItem.price}" type="currency" currencySymbol="VNĐ"/></strike>
                        <fmt:formatNumber value="${selectedItem.price * (1 - selectedItem.discount)}" type="currency" currencySymbol="VNĐ"/>
                    </div>

                    <div class="card-description">
                        <p>Mô tả: Đây là sản phẩm <strong>${selectedItem.name}</strong> với chất lượng tuyệt vời, phù hợp cho nhu cầu sử dụng hàng ngày và làm quà tặng.</p>
                    </div>

                    <div class="card-action">
                        <a href="bai5">Trở về danh sách</a>
                    </div>
                </div>
            </div>
        </c:if>

        <c:if test="${empty selectedItem}">
            <div class="not-found">
                Sản phẩm không tồn tại hoặc đã bị xóa!
            </div>
        </c:if>
    </div>
</body>
</html>