package poly.com.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/bai4")
public class NewsServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Map<String, Object> map = new HashMap<>();
		map.put("title", "iPhone 17 pro max");
		map.put("content",
			    "iPhone 17 Pro Max là mẫu flagship ra mắt năm 2024 với thiết kế tinh tế, "
			  + "hiệu năng cực mạnh và cụm camera nâng cấp ấn tượng. Thiết bị sở hữu màn hình "
			  + "hiển thị sắc nét, pin lớn và nhiều tính năng AI mới giúp trải nghiệm người dùng "
			  + "mượt mà hơn bao giờ hết.");
		req.setAttribute("item", map);
		req.getRequestDispatcher("/news.jsp").forward(req, resp);
	}
}
