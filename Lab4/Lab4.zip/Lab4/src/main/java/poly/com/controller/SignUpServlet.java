package poly.com.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/signup")
public class SignUpServlet extends HttpServlet {
	@Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.getRequestDispatcher("signup.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String gender   = req.getParameter("gender");
        String married  = req.getParameter("married");
        String country  = req.getParameter("country");
        String note     = req.getParameter("note");

        String[] hobbies = req.getParameterValues("hobby");

        System.out.println("THÔNG TIN FORM ĐĂNG KÝ");
        System.out.println("Tên đăng nhập: " + username);
        System.out.println("Mật khẩu: " + password);
        System.out.println("Giới tính: " + gender);
        System.out.println("Đã có gia đình: " + married);
        System.out.println("Quốc tịch: " + country);
        System.out.println("Ghi chú: " + note);

        System.out.print("Sở thích: ");
        if (hobbies != null) {
            for (String h : hobbies) {
                System.out.print(h + " ");
            }
        } else {
            System.out.print("Không có");
        }
        System.out.println();
    }
}
