package poly.com.controller;

import java.io.File;
import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
@WebServlet("/upload")
@MultipartConfig
public class UploadServlet extends HttpServlet {
	 	@Override
	    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
	            throws ServletException, IOException {

	        req.getRequestDispatcher("/upload.jsp").forward(req, resp);
	    }

	    @Override
	    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
	            throws ServletException, IOException {

	    	resp.setContentType("text/html; charset=UTF-8");
	    	req.setCharacterEncoding("UTF-8");

	        Part photo = req.getPart("photo");

	        String fileName = photo.getSubmittedFileName();

	        String uploadPath = req.getServletContext().getRealPath("/static/file");

	        File dir = new File(uploadPath);
	        if (!dir.exists()) {
	            dir.mkdirs();
	        }

	        photo.write(uploadPath + "/" + fileName);

	        resp.getWriter().println("Upload thành công! File đã lưu tại /static/file/" + fileName);
	    }
}
