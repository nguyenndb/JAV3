<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Lab4</title>
</head>
<body>
<a href="account/login">Bài 1</a> ||
<a href="calculate/add">Bài 2</a> ||
<a href="signup">Bài 3</a> ||
<a href="upload">Bài 4</a> ||
</body>
</html>