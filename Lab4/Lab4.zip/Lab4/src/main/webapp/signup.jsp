<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<h1>Đăng Ký</h1>
    <form action="signup" method="post">
        Tên đăng nhập: <br>
        <input name="username"> <br><br>
        Mật khẩu: <br>
        <input type="password" name="password"> <br><br>
        Giới tính: <br>
        <input type="radio" name="gender" value="Nam" checked> Nam
        <input type="radio" name="gender" value="Nữ"> Nữ <br><br>
        <input type="checkbox" name="married" value="true"> Đã có gia đình? <br><br>
        Quốc tịch: <br>
        <select name="country">
            <option value="VN">Vietnam</option>
            <option value="US">United States</option>
            <option value="JP">Japan</option>
        </select>
        <br><br>
        Sở thích: <br>
        <input type="checkbox" name="hobby" value="Đọc sách"> Đọc sách
        <input type="checkbox" name="hobby" value="Du lịch"> Du lịch
        <input type="checkbox" name="hobby" value="Âm nhạc"> Âm nhạc
        <input type="checkbox" name="hobby" value="Khác"> Khác
        <br><br>
        Ghi chú: <br>
        <textarea name="note" rows="4" cols="40"></textarea>
        <br><br>
        <button type="submit">Đăng ký</button>
    </form>
</body>
</html>