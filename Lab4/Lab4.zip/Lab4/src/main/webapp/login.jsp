<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<h3>Login Form</h3>	
	<c:url value="/account/login" var="url"/>
	<form action="${url}" method="post">
	    <input name="username"><br>
	    <input name="password" type="password"><br>
	    <button>Login</button>
	</form>
	
	<p>${message}</p>
</body>
</html>