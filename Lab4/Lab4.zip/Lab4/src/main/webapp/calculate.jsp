<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<h3>Calculator</h3>	
	<c:url value="/calculate" var="cal"/>	
	<form method="post">
	    <input name="a" placeholder="Số thứ nhất"><br>
	    <input name="b" placeholder="Số thứ hai"><br>
	    <button formaction="${cal}/add">+</button>
	    <button formaction="${cal}/sub">-</button>
	</form>	
	<p>${message}</p>
</body>
</html>