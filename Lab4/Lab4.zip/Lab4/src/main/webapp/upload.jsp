<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<h2>Upload Image</h2>
	<c:url value="/upload" var="url" />
	<form action="${url}" method="post" enctype="multipart/form-data">
	    <input name="photo" type="file"><br><br>
	    <button type="submit">Upload</button>
	</form>
</body>
</html>