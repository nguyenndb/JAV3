<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<hr/>
<a href="bai1">Bài 1</a> ||<a href="bai2">Bài 2</a> ||<a href="bai3">Bài 3</a> ||<a href="bai4">Bài 4</a>
<hr/>
<h1>đây là bài 1</h1>
</body>
</html>