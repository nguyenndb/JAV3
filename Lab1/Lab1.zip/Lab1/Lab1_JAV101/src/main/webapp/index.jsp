<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>website bán hàng</title>
</head>
<body>
<hr/>
<a href="bai1">Bài 1</a> ||<a href="bai2">Bài 2</a> ||<a href="bai3">Bài 3</a> ||<a href="bai4">Bài 4</a> ||
<a href="crud/create">thêm</a> || <a href="crud/update">cập nhật</a> || <a href="crud/delete">xóa</a> || <a href="crud/edit/2024">chỉnh sửa</a>
<hr/>
</body>
</html>